module com.example.week12javafxdemo {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.week12javafxdemo to javafx.fxml;
    exports com.example.week12javafxdemo;
}