module com.example.hotsauceapp {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.hotsauceapp to javafx.fxml;
    exports com.example.hotsauceapp;
}