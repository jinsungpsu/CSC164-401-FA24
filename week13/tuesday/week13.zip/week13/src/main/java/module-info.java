module com.example.week13 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.week13 to javafx.fxml;
    exports com.example.week13;
}