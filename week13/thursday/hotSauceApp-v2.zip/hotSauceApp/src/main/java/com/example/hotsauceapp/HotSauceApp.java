package com.example.hotsauceapp;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class HotSauceApp extends Application {
    public static ArrayList<HotSauce> hotSauceInventory = new ArrayList<>();
    public static HotSauce selectedSauce;

    @Override
    public void start(Stage stage) throws IOException {
        loadSaucesFromFile();

        FXMLLoader fxmlLoader = new FXMLLoader(HotSauceApp.class.getResource("hello-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 800, 600);
        stage.setTitle("Hot Sauce App!");
        stage.setScene(scene);
        stage.show();
    }


    private void loadSaucesFromFile() {
        try {
            Scanner fileinput = new Scanner(new File("src/output.txt"));
            while(fileinput.hasNext()) {
                // format of the file
                // brand, name, calories, lethal
                String brand = fileinput.next();
                String name = fileinput.next();
                int calories = Integer.parseInt(fileinput.next());
                boolean lethal = Boolean.parseBoolean(fileinput.next());

                HotSauce temp = new HotSauce(brand, name, calories, lethal);

                HotSauceApp.hotSauceInventory.add(temp);
            }
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (InputMismatchException e) {
            // deal with this specific kind of problem
        } catch (Exception e) {
            // nooooooooooo
        }
        // absolute vs relative filepath
        // C:\ClassCode FA24\CSC164-401-FA24\hotSauceApp\src\sauces.txt
    }

    public static void main(String[] args) {
        launch();
    }
}